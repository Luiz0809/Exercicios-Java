
package Lista02;
public class NumerosImpares {
    public static void main(String[] args) {
        
        for (int c = 0; c <= 90; c++){
        if (c%2 == 1){
            System.out.println(c);}
        }
    }
 
}
